import time, requests
import pandas as pd
import numpy as np

proxies = {"http": "http://webproxy.bfm.com","https":"http://webproxy.bfm.com"}

proxies = {
 'http': 'http://sgp-webproxy.blackrock.com:8080',
 'https': 'http://sgp-webproxy.blackrock.com:8080',
}


config = pd.read_excel('Config.xlsx', sheet_name='Config', keep_default_na=False)
config = config[config['Country'] == 'China'].reset_index(drop=True).copy()

"""抓取每日确诊和死亡数据"""

outputDf = pd.DataFrame()

for index, row in config.iterrows():
    
    province = row['Province(Chinese)']
    print(province)
    
    url = 'https://lab.isaaclin.cn/nCoV/api/area?latest=0&province='+province
    
    data = requests.get(url=url, proxies=proxies, verify=False).json()
    data = data['results']
    
    tempDf = pd.DataFrame(data)
    tempDf['updateDateTime'] = tempDf['updateTime'].apply(lambda epoch: time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(epoch/1000)))
    tempDf['updateDate'] = tempDf['updateTime'].apply(lambda epoch: time.strftime('%Y-%m-%d', time.localtime(epoch/1000)))
    tempDf['updateTime'] = pd.to_numeric(tempDf['updateTime'].apply(lambda epoch: time.strftime('%H%M%S', time.localtime(epoch/1000))))
    tempDf['distance to 12'] = np.where(tempDf['updateTime'] >= 130000, 120000, np.abs(tempDf['updateTime'] - 120000))
    
    tempDf = tempDf.sort_values(['distance to 12'], ascending=[1]).reset_index(drop=True).copy()
    
    tempDf.drop_duplicates(subset=['updateDate'], keep='first', inplace=True)
    tempDf = tempDf.sort_values(['updateDate'], ascending=[1]).reset_index(drop=True).copy()
    
    tempDf['addedConfirmedCount'] = tempDf['confirmedCount'].diff()
    tempDf['addedCuredCount'] = tempDf['curedCount'].diff()
    tempDf['addedDeadCount'] = tempDf['deadCount'].diff()
    tempDf['addedSuspectedCount'] = tempDf['suspectedCount'].diff()
    
    tempDf['confirmedCountGrowth'] = tempDf['addedConfirmedCount'] / (tempDf['confirmedCount'] - tempDf['addedConfirmedCount'])
    tempDf['curedCountGrowth'] = tempDf['addedCuredCount'] / (tempDf['curedCount'] - tempDf['addedCuredCount'])
    tempDf['deadCountGrowth'] = tempDf['addedDeadCount'] / (tempDf['deadCount'] - tempDf['addedDeadCount'])
    tempDf['suspectedCountGrowth'] = tempDf['addedSuspectedCount'] / (tempDf['suspectedCount'] - tempDf['addedSuspectedCount'])
    
    tempDf['Province'] = row['Province']
    tempDf['Country'] = row['Country']
    
    outputDf = pd.concat([outputDf, tempDf[['provinceName','Province','Country','confirmedCount','addedConfirmedCount','confirmedCountGrowth','curedCount','addedCuredCount','curedCountGrowth','deadCount','addedDeadCount','deadCountGrowth','suspectedCount','addedSuspectedCount','suspectedCountGrowth','updateDate','updateDateTime']]], copy=True)
    
outputDf.to_csv('output.csv', index=False, encoding='utf_8_sig')